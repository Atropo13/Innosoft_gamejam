extends Node2D
@onready var tiempo: Timer = $Timer
@onready var temporizador: Control = $ui/temporizador
@onready var ui: Control = $ui
@onready var ui_mini_2: Control = $ui_mini2
var lados1 = 0
var lados2 = 0
@onready var bordes_pan: Node3D = $bordes_pan
@onready var bordes_pan_2: Node3D = $bordes_pan2
var combinacion1 = []
var combinacion2 = []
signal cambio
var puntuacion1 = 0
var puntuacion2 = 0
var time_end = true
@onready var audio_stream: AudioStreamPlayer = $AudioStreamPlayer
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	temporizador.visible = true
	combinacion1 = reroll()
	combinacion2 = reroll()
	ui_mini_2.guardar_combinacion(combinacion1, combinacion2)
func _input(event: InputEvent) -> void:
		if time_end :
			if event.is_action_pressed("arriba1") and combinacion1[lados1] == "arriba":
				lados1 += 1
				bordes_pan.quitar_borde("arriba")
				
			elif event.is_action_pressed("izquierda1")  and combinacion1[lados1] == "izquierda" :
				lados1 +=1
				bordes_pan.quitar_borde("izquierda")
			elif event.is_action_pressed("abajo1")  and combinacion1[lados1] == "abajo":
				lados1 += 1
				bordes_pan.quitar_borde("abajo")
			elif event.is_action_pressed("derecha1") and  combinacion1[lados1] == "derecha":
				lados1 +=1
				bordes_pan.quitar_borde("derecha")
				
			if event.is_action_pressed("arriba2")  and combinacion2[lados2] == "arriba":
				lados2 += 1
				bordes_pan_2.quitar_borde("arriba")
			elif event.is_action_pressed("izquierda2") and combinacion2[lados2] == "izquierda" :
				lados2 += 1
				bordes_pan_2.quitar_borde("izquierda")
			elif event.is_action_pressed("abajo2") and combinacion2[lados2] == "abajo":
				lados2 += 1

				bordes_pan_2.quitar_borde("abajo")
			elif event.is_action_pressed("derecha2") and combinacion2[lados2] == "derecha":
				lados2 += 1
				bordes_pan_2.quitar_borde("derecha")
		else:
			if event.is_action_pressed("ui_accept") :
				Global.start()
func pan_2_cortada() -> void:
	combinacion2 = reroll()
	cambio.emit(2)
	ui_mini_2.guardar_combinacion([], combinacion2)
	lados2 = 0
	puntuacion2 += 1

func pan_cortada() -> void:
	combinacion1 = reroll()
	cambio.emit(1)
	ui_mini_2.guardar_combinacion(combinacion1, [])
	lados1 = 0
	puntuacion1 += 1
func reroll():
	var direcciones = ["arriba", "abajo", "derecha","izquierda"]
	var i = 3
	var temp:Array
	while i > -1:
		temp.append(direcciones[randi_range(0,i)])
		direcciones.erase(temp[-1])
		i -= 1

	return temp
func _process(delta: float) -> void:
	temporizador.text = str(int(tiempo.time_left))


func _on_timer_timeout() -> void:
		audio_stream.play(6.0)
		time_end = false
		Global.puntuacion1 += int(puntuacion1) * 10
		Global.puntuacion2 += int(puntuacion2) * 10
		ui.sumar_puntuaciones(Global.puntuacion1, Global.puntuacion2)
		
