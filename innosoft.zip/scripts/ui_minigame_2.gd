extends Control
@onready var label1: Label = $CuboAzul/Label
@onready var label2: Label = $CuboAzul2/Label
@onready var label3: Label = $CuboAzul3/Label
@onready var label4: Label = $CuboAzul4/Label
@onready var arrow: Sprite2D = $cubo_rojo/ArrowRight
@onready var arrow_2: Sprite2D = $cubo_rojo2/ArrowRight2
@onready var arrow_3: Sprite2D = $cubo_rojo3/ArrowRight3
@onready var arrow_4: Sprite2D = $cubo_rojo4/ArrowRight4

var letras = {"derecha": "D", "arriba": "W","izquierda": "A", "abajo": "S"}
var grados = {"derecha": 0, "arriba": 270,"izquierda": 180, "abajo": 90}
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func guardar_combinacion(conjunto1:Array, conjunto2:Array):
	print(conjunto1)
	print(conjunto2)
	if conjunto1.size() == 4:
		for i in conjunto1:
			if label1.text == "":
				label1.text = letras[i]
			elif label2.text == "":
				label2.text = letras[i]
			elif label3.text == "":
				label3.text = letras[i]
			elif label4.text == "":
				label4.text = letras[i]
			
	if conjunto2.size() == 4:
		for i in conjunto2:
		
			if arrow.rotation_degrees == 360:
				arrow.rotation_degrees = grados[i]
			elif arrow_2.rotation_degrees == 360:
				arrow_2.rotation_degrees = grados[i]
			elif arrow_3.rotation_degrees == 360:
				arrow_3.rotation_degrees = grados[i]
			elif arrow_4.rotation_degrees == 360:
				arrow_4.rotation_degrees = grados[i]
			

func _on_minijuego_2_cambio(jdr) -> void:
	if jdr == 1:
		label1.text = ""
		label2.text = ""
		label3.text = ""
		label4.text = ""
	elif jdr == 2:
		arrow.rotation_degrees = 360
		arrow_2.rotation_degrees = 360
		arrow_3.rotation_degrees = 360
		arrow_4.rotation_degrees = 360
		
