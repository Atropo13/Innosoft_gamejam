extends Node3D

@onready var arriba_borde: MeshInstance3D = $arriba_borde
@onready var abajo_borde: MeshInstance3D = $abajo_borde
@onready var izquierda_borde: MeshInstance3D = $izquierda_borde
@onready var derecha_borde: MeshInstance3D = $derecha_borde
signal cortada
var sin_lados = 0
func quitar_borde(lado):
	if lado == "arriba":
		arriba_borde.visible = false
		sin_lados +=1
	elif lado == "abajo":
		abajo_borde.visible = false
		sin_lados +=1

	elif lado =="derecha":
		derecha_borde.visible = false
		sin_lados +=1

	elif lado =="izquierda":
		izquierda_borde.visible = false
		sin_lados +=1
	if sin_lados == 4:
		cortada.emit()
		sin_lados= 0
		izquierda_borde.visible = true
		abajo_borde.visible = true
		arriba_borde.visible = true
		derecha_borde.visible = true
