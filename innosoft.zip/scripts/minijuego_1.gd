extends Node3D
signal anim_finish
@onready var animation_player: AnimationPlayer = $AnimationPlayer

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	anim_finish.emit(anim_name)
func start_anim(name_anim: String):
	if name_anim == "Sacar_pan":
		animation_player.play_backwards(name_anim)
	else:
		animation_player.play(name_anim)
	
	
