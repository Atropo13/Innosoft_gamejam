extends Node2D


func _ready():
	print("READY ejecutado")



func _notification(what):
	if what == NOTIFICATION_WM_WINDOW_FOCUS_IN:
		print("La ventana tiene el foco")

	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		print("La ventana ha perdido el foco")
func _input(event: InputEvent) -> void:
	print("pruebas")
	if event.is_action_pressed("ui_accept") :
		print("funciona la prueba")
