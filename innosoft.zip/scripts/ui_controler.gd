extends Control
@onready var puntuacion_bar_1: TextureProgressBar = $TextureProgressBar
@onready var puntuacion_bar_2: TextureProgressBar = $TextureProgressBar2
@onready var winner_round_2: Label = $winner_round2
@onready var winner_round: Label = $winner_round

var tween:Tween
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	puntuacion_bar_1.visible = false
	puntuacion_bar_2.visible = false

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func sumar_puntuaciones(puntuacion1, puntuacion2) -> void:
	print(puntuacion1, puntuacion2)
	var temp3 = 0
	var temp1
	var temp2
	puntuacion_bar_1.value += puntuacion1
	puntuacion_bar_2.value += puntuacion2
	if puntuacion_bar_1.value > puntuacion_bar_1.value:
		puntuacion_bar_1.max_value = puntuacion_bar_1.value
		puntuacion_bar_2.max_value = puntuacion_bar_1.value
	else:
		puntuacion_bar_1.max_value = puntuacion_bar_2.value
		puntuacion_bar_2.max_value = puntuacion_bar_2.value
		temp1 = puntuacion_bar_1.value 
		temp2 = puntuacion_bar_2.value 
		puntuacion_bar_1.value = 0
		puntuacion_bar_2.value = 0
	puntuacion_bar_1.visible = true
	puntuacion_bar_2.visible = true
	if tween:
		tween.kill()
	tween = create_tween()
	
	tween.tween_property(puntuacion_bar_1, "value", temp1 / 2.0, 1.5)
	tween.parallel().tween_property(puntuacion_bar_2, "value", temp2 / 2.0, 1.5)

	# Fase 2: segunda mitad, rápida
	tween.tween_property(puntuacion_bar_1, "value", temp1, 0.4)
	tween.parallel().tween_property(puntuacion_bar_2, "value", temp2, 0.4)
	
	
	tween.finished.connect(al_terminar.bind(puntuacion_bar_1.value, puntuacion_bar_2.value))

func al_terminar(punt1, punt2) -> void:
	print("animación terminada")
	if punt1 > punt2:
		winner_round.visible = true
	else:
		winner_round_2.visible = true
		
	
