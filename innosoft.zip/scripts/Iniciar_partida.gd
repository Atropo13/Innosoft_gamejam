extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass



func _button_down() -> void:
	Global.start()


func ver_puntuaciones() -> void:
	get_tree().change_scene_to_packed(preload("res://scenes/puntuaciones.tscn"))


func _on_creditos_button_down() -> void:
	get_tree().change_scene_to_packed(preload("res://scenes/creditos.tscn"))
