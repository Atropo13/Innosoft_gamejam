extends Node3D
@onready var temporizador: Control = $Control/temporizador
@onready var tiempo_secundario: Timer = $tiempo_secundario
var puntuacion1 = 0
var puntuacion2 = 0
@onready var timer: Timer = $Timer
var anterior = 90
var finish = false
@onready var horno: Node3D = $horno
signal sumar_puntuacion
var cambio = false
@onready var audio_player: AudioStreamPlayer = $AudioStreamPlayer

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	horno.start_anim("Guardar_pan")
	temporizador.visible = false
	set_process_input(true)
	
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	var tiempo_restante = timer.time_left
	tiempo_restante = int(tiempo_restante)
	if tiempo_restante <anterior:
		temporizador.text = str(tiempo_restante - 15)

		anterior = tiempo_restante
		
	

func _input(event: InputEvent) -> void:
	if !timer.is_stopped():
		
		if event.is_action_pressed("arriba1") and puntuacion1 == 0:
			puntuacion1 = 10 *(90 -timer.time_left)
			print(puntuacion1)
			if puntuacion2 != 0:
				finished()
		
		if event.is_action_pressed("arriba2") and puntuacion2 == 0:
			puntuacion2 = 10 *(90 -timer.time_left)
			print(puntuacion2)
			if puntuacion1 != 0 :
				finished()
		if event.is_action_pressed("ui_accept") and cambio:
			Global.start()
func timeout_ocultar_tiempo() -> void:
	temporizador.visible = false


func anim_finish(anim_name:String) -> void:
	if anim_name == "Guardar_pan" :
		temporizador.visible = true
		timer.start(randi_range(30,90))
		anterior =1 + timer.time_left
		tiempo_secundario.start(6)
	if anim_name == "Sacar_pan":
		audio_player.play(6.0)
		Global.puntuacion1 += int(puntuacion1)
		Global.puntuacion2 += int(puntuacion2)
		sumar_puntuacion.emit(Global.puntuacion1, Global.puntuacion2)
		cambio = true
		

func finished():
		horno.start_anim("Sacar_pan")
		

func timeotu_pan() -> void:
	finished()
