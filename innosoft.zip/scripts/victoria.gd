extends Control

@onready var line_edit: LineEdit = $LineEdit

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Global.puntuacion1 > Global.puntuacion2:
		$Label.text = ("Felicidades cocinero 1 has ganado,¿ COMO  TE LLAMAS?")
	elif Global.puntuacion1 < Global.puntuacion2:
		$Label.text = ("Felicidades cocinero 2 has ganado,¿ COMO  TE LLAMAS?")
	else:
		$Label.text = ("Habeis empatado, elejid  un  nombre  entre  los  2")
	$Label2.text = ("Puntuacion  total:"  + str(max(Global.puntuacion1, Global.puntuacion2)))



func text_submited(new_text: String) -> void:
	Global.puntuaciones_globales = Global.nueva_puntuacion(new_text,max(Global.puntuacion1, Global.puntuacion2))
	get_tree().change_scene_to_packed(preload("res://scenes/main.tscn"))
