extends Node
var puntuacion1 = 0
var puntuacion2 = 0
var minijuego1 = preload("res://scenes/minijuego1.tscn")
var main = preload("res://scenes/main.tscn")
var minijuego2 = preload("res://scenes/minijuego2.tscn")
var minijuegos_jugados = 0
var puntuaciones_globales:Dictionary = {}
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func cargar_main():
	get_tree().change_scene_to_packed(main)
func cargar_min2():
		get_tree().change_scene_to_packed(minijuego2)

func cargar_min1():
			get_tree().change_scene_to_packed(minijuego1)
func cargar_puntuacion():
		get_tree().change_scene_to_packed(preload("res://scenes/Victoria.tscn"))

func _unhandled_input(event):
	
	
	if event is InputEventKey:
		if event.pressed and event.keycode == KEY_ESCAPE:
			get_tree().quit()
func start():
	if minijuegos_jugados % 4 == 0 and !minijuegos_jugados == 0:
			cargar_puntuacion()
			minijuegos_jugados = 0
	else:
		if minijuegos_jugados % 2 == 0:
			cargar_min1()
		else:
			cargar_min2()
	minijuegos_jugados +=1 

func nueva_puntuacion(nueva_clave, puntuacion):
	var nuevo_diccionario:Dictionary = {}
	if puntuaciones_globales.has(nueva_clave):
		puntuaciones_globales.erase(nueva_clave)
		for clave in puntuaciones_globales:
			if puntuaciones_globales[clave] <= puntuacion:
				nuevo_diccionario[nueva_clave] = puntuacion
				nuevo_diccionario[clave]= puntuaciones_globales[clave]
			else:
				nuevo_diccionario[clave]= puntuaciones_globales[clave]
				
	else:
		for clave in puntuaciones_globales:
			if puntuaciones_globales[clave] <= puntuacion:
				nuevo_diccionario[nueva_clave] = puntuacion
				nuevo_diccionario[clave]= puntuaciones_globales[clave]
			else:
				nuevo_diccionario[clave]= puntuaciones_globales[clave]
	if puntuaciones_globales.size() == 0:
		nuevo_diccionario[nueva_clave] = puntuacion
	return nuevo_diccionario
				
	
