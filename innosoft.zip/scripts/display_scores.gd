extends Control

var nueva_puntuacion = Label.new()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	muestra_puntos(Global.puntuaciones_globales)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func muestra_puntos(puntuaciones: Dictionary):
	for clave in puntuaciones:
		nueva_puntuacion.text = "%s: %d" % [clave, puntuaciones[clave]]
		add_child(nueva_puntuacion)
	

	


func volver() -> void:
		Global.cargar_main()

		
